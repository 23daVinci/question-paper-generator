<?php 
/*$qno1 = 1;
$i = 1;
$qno1."-".$i;
 $q = $qno1."-".$i;
echo $q;
$q = "sax";
echo $q;*/
$q = "sax";
echo "<br>";
for($i=1;$i<=5;$i++){
	$q = "sax";
	$q-$i = $i;
	echo $q-$i;
	echo "<br>";
}
