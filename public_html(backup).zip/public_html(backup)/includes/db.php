<?php $conn = mysqli_connect("localhost","root","","aws");
if(mysqli_connect_error()){
	echo "error in connection";
}
?>