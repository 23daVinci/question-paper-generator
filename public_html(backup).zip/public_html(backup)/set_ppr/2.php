<?php 
ob_start();
session_start();
include("../includes/db.php");
include("../includes/function.php");

		 $branch = $_SESSION['branch']; 	
		 $sem = $_SESSION['sem'];
		 $sub = $_SESSION['sub'];

$query = "select * from ".$branch." where sub ='".$sub."'";
$result = mysqli_query($conn,$query);
$id = array();
while($row = mysqli_fetch_array($result)){
	 $quest_id = $row['id'];
	 $quest_id = array($quest_id);
	$id = array_merge($id,$quest_id);
}

  $id = implode(',',$id);
if(isset($_POST['co'])){
	 $co = $_POST['co'];
	  $no = $_POST['no'];
	if(!empty($co)){
$query = "Select * from it where co = '".$co."'and id in(".$id.") ";
$result = mysqli_query($conn,$query);
//query_check($result);
	$id = array();
while($row = mysqli_fetch_assoc($result)){
	 $quest_id = array($row['id']);
		$id = array_merge($id,$quest_id);
	$quest = $row['quest'];
	?>
	<li onclick="fill('<?php echo $quest; ?>','<?php echo $no; ?>')"><a><?php echo $quest; ?></a></li>
	<?php
}
		$_SESSION['id'] = $id;
		
}
}
else{
	echo "not co";
}

?>