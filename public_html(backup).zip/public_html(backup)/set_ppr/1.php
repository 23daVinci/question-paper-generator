<?php session_start();
if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}

?>
<?php 
ob_start();

if(isset($_POST['add_quest'])){
		$_SESSION['branch'] = $branch = $_POST['branch'];
		$_SESSION['etype'] = $etype = $_POST['etype'];
        if($etype == "Prelims") {
            $marks = 80;
            $_SESSION['marks'] = $marks;
            $time = "3 hrs";
            $_SESSION['time'] = $time;
        }
        else{
            $marks = 20;
            $time = "1 hr";
        }
		$_SESSION['edate'] = $edate =date('d/m/Y', strtotime($_POST['edate']));
		//$_SESSION['emrk'] = $emrk = $_POST['emrk']; // Total marks
		//$_SESSION['etime'] = $etime = $_POST['etime'];
		$_SESSION['sem'] = $sem = $_POST['sem'];
		$sub = "sem-".$sem;
		$_SESSION['sub'] = $sub = $_POST[$sub];
}
?>



<!DOCTYPE html>

<html lang='en'>

<head>

	<meta charset='UTF-8'>

	<title>Document</title>
	<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>

	<style>
		body {
			margin: 0;
			font-family: Arial, Helvetica, sans-serif;
			background-color: #ab89f0;


		}

		.topnav {
			overflow: hidden;
			background-color: #141414;
		}

		.topnav a {
			float: left;
			display: block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size: 17px;
		}

		.topnav a:hover {
			background-color: rgba(239, 233, 233, 0.54);
			color: black;
		}

		.active {
			background-color: #4fea55;
			color: black;
		}

		.topnav .icon {
			display: none;
		}

		@media screen and (max-width: 600px) {
			.topnav a:not(:first-child) {
				display: none;
			}

			.topnav a.icon {
				float: right;
				display: block;
			}
		}

		@media screen and (max-width: 600px) {
			.topnav.responsive {
				position: relative;
			}

			.topnav.responsive .icon {
				position: absolute;
				right: 0;
				top: 0;
			}

			.topnav.responsive a {
				float: none;
				display: block;
				text-align: left;
			}
		}

		* {
			box-sizing: border-box;
		}

		#myInput {
			background-position: 10px 12px;
			background-repeat: no-repeat;
			width: 100%;
			font-size: 16px;
			padding: 12px 20px 12px 40px;
			border: 1px solid #ddd;
			margin-bottom: 12px;
		}

		.result {
			list-style-type: none;
			padding: 0;
			margin: 0;
			margin-top: -12px;
		}

		.result li a {
			border: 1px solid #ddd;
			margin-top: -1px;
			/* Prevent double borders */
			background-color: #f6f6f6;
			padding: 12px;
			text-decoration: none;
			font-size: 18px;
			color: black;
			display: block
		}

		.result li a:hover:not(.header) {
			background-color: #eee;
		}

	</style>
</head>

<body>
	<div class="topnav" id="myTopnav">
		<a href="" class="active"><b>ELiT</b></a>
		<a href="../admin/index.php"><b>Dashboard</b></a>
		<a href="../admin/prev_ppr.php"><b>Previous papers</b></a>
		<a href="../admin/calendar.php"><b>Planner</b></a>
		<a href="../login/logout.php"><b>Logout</b></a>
		<a href="javascript:void(0);" class="icon" onclick="myFunction()">
			<i class="fa fa-bars"></i>
		</a>
	</div>

	<br>
	<?php
        
        if ($etype == "Prelims") {
            include "includes/prelims.php";
        }
        else {
            include "includes/ut.php";
        }
    ?>
	<br>
	<br>
	<br>

	<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
	<!--<script src='//code.jquery.com/jquery-1.11.2.min.js'></script>-->
	<script src='../js/jquery-1.11.0.min.js'></script>

	<script>
		$(document).ready(function() {


			<?php 	
	for($i=1;$i<=5;$i++){		
print("

			$('#co1-". $i."').keyup(function() {
				var co = $('#co1-". $i." option:selected').val();
				$.ajax({
					url: '2.php',
					data: {
						co: co,
						no: '1-".$i."'
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result1-". $i."').html(data).show();
						}
					}
				});
			});

			$('#quest1-". $i."').keyup(function() {
				var quest = $('#quest1-". $i."').val();
				$.ajax({
					url: '3.php',
					data: {
						quest: quest,
						
						no: '1-".$i."'
						
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result1-". $i."').html(data).show();
							
						}
					}
				});
			});

");
	}
					
				for($i=1;$i<=2;$i++){		
print("
			$('#co2-". $i."').keyup(function() {
				var co = $('#co2-". $i." option:selected').val();
				$.ajax({
					url: '2.php',
					data: {
						co: co,
						no: '2-".$i."'
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result2-". $i."').html(data).show();
						}
					}
				});
			});

			$('#quest2-". $i."').keyup(function() {
				var quest = $('#quest2-". $i."').val();
				$.ajax({
					url: '3.php',
					data: {
						quest: quest,
						no: '2-".$i."'
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result2-". $i."').html(data).show();
							
						}
					}
				});
			});

");
	}






for($i=1;$i<=2;$i++){		
print("
			$('#co3-". $i."').keyup(function() {
				var co = $('#co3-". $i." option:selected').val();
				$.ajax({
					url: '2.php',
					data: {
						co: co,
						no: 3-".$i."
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result3-". $i."').html(data).show();
						}
					}
				});
			});

			$('#quest3-". $i."').keyup(function() {
				var quest = $('#quest3-". $i."').val();
				$.ajax({
					url: '3.php',
					data: {
						quest: quest,
						no: 3-".$i."
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result3-". $i."').html(data).show();
							
						}
					}
				});
			});

");
	}


		?>


		});


		function fill(Value, NO) {


			$('#quest' + NO).val(Value);
			$('#result' + NO).hide();


		}

	</script>

</body>

</html>
