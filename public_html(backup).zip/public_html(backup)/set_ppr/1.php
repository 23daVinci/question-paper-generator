<?php session_start();
if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}

?>
<?php 
ob_start();

if(isset($_POST['add_quest'])){
		$_SESSION['branch'] = $branch = $_POST['branch'];
		$_SESSION['etype'] = $etype = $_POST['etype'];
		$_SESSION['edate'] = $edate =date('d/m/Y', strtotime($_POST['edate']));
		$_SESSION['emrk'] = $emrk = $_POST['emrk'];
		$_SESSION['etime'] = $etime = $_POST['etime'];
		$_SESSION['sem'] = $sem = $_POST['sem'];
		$sub = "sem-".$sem;
		$_SESSION['sub'] = $sub = $_POST[$sub];
}
?>



<!DOCTYPE html>

<html lang='en'>

<head>

	<meta charset='UTF-8'>

	<title>Document</title>
	<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>

	<style>
		body {
			margin: 0;
			font-family: Arial, Helvetica, sans-serif;
			background-color: #ab89f0;


		}

		.topnav {
			overflow: hidden;
			background-color: #141414;
		}

		.topnav a {
			float: left;
			display: block;
			color: white;
			text-align: center;
			padding: 14px 16px;
			text-decoration: none;
			font-size: 17px;
		}

		.topnav a:hover {
			background-color: rgba(239, 233, 233, 0.54);
			color: black;
		}

		.active {
			background-color: #4fea55;
			color: black;
		}

		.topnav .icon {
			display: none;
		}

		@media screen and (max-width: 600px) {
			.topnav a:not(:first-child) {
				display: none;
			}

			.topnav a.icon {
				float: right;
				display: block;
			}
		}

		@media screen and (max-width: 600px) {
			.topnav.responsive {
				position: relative;
			}

			.topnav.responsive .icon {
				position: absolute;
				right: 0;
				top: 0;
			}

			.topnav.responsive a {
				float: none;
				display: block;
				text-align: left;
			}
		}

		* {
			box-sizing: border-box;
		}

		#myInput {
			background-position: 10px 12px;
			background-repeat: no-repeat;
			width: 100%;
			font-size: 16px;
			padding: 12px 20px 12px 40px;
			border: 1px solid #ddd;
			margin-bottom: 12px;
		}

		.result {
			list-style-type: none;
			padding: 0;
			margin: 0;
			margin-top: -12px;
		}

		.result li a {
			border: 1px solid #ddd;
			margin-top: -1px;
			/* Prevent double borders */
			background-color: #f6f6f6;
			padding: 12px;
			text-decoration: none;
			font-size: 18px;
			color: black;
			display: block
		}

		.result li a:hover:not(.header) {
			background-color: #eee;
		}

	</style>
</head>

<body>
	<div class="topnav" id="myTopnav">
		<a href="" class="active"><b>ELiT</b></a>
		<a href="../admin/index.php"><b>Dashboard</b></a>
		<a href="../admin/prev_ppr.php"><b>Previous papers</b></a>
		<a href="../admin/calendar.php"><b>Planner</b></a>
		<a href="../login/logout.php"><b>Logout</b></a>
		<a href="javascript:void(0);" class="icon" onclick="myFunction()">
			<i class="fa fa-bars"></i>
		</a>
	</div>

	<br>
	<form action="4.php" method="post">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h1 style="text-align: center; color: white;"><b>F.C.R.I.T. Question paper manager</b></h1>
					<br>
					<br>
				</div>
			</div>

			<div class="jumbotron">
				<h3 class="display-5 ">
					<p class="text-center">
						<span class="text-left">Branch:
							<?php echo  $branch."-".$sem; ?></span>
						<span class="text-right">Subject:
							<?php echo  $sub;?></span>
						<span class="text-right">Date:
							<?php echo  $edate;?></span>
						<span class="text-right">Papper:
							<?php echo  $etype;?></span>
						<span class="text-right">Mark:
							<?php echo  $emrk;?></span>
						<span class="text-right">Toal Time:
							<?php echo  $etime;?></span>


					</p>

				</h3>
			</div>

			<!-- paper entry -->

			<br>
			<h3 style="color: white">Question 1.</h3><br>
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<textarea name="title1" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
				</div>
			</div><br>
			<?php 

for($i=1;$i<=5;$i++){
	print("
<div class='row'>

				<div class='col-sm-2'>
					<select class='form-control' name='qno1-".$i."' id='qno1-".$i."'>
						<option value=''>--</option>
						<option value='1a'>1a</option>
						<option value='1b'>1b</option>
						<option value='1c'>1c</option>
						<option value='1d'>1d</option>
						<option value='1e'>1e</option>
					
					</select>
				</div>
				<div class='col-sm-2'>

					<select class='form-control' id='co1-".$i."' name='co1-".$i."'>
						<option value=''>--</option>
						<option value='1'>CO1</option>
						<option value='2'>CO2</option>
						<option value='3'>CO3</option>
						<option value='4'>CO4</option>
						<option value='5'>CO5</option>
						<option value='6'>CO6</option>
					</select>

				</div>
				<div class='col-sm-6'>
					<textarea class='form-control' name='quest1-".$i."' id='quest1-".$i."' placeholder='question'></textarea>
					<ul class='result' id='result1-".$i."'>

					</ul>
				</div>
				<div class='col-sm-1'>
					<input type='text' name='mrk1-".$i."' class='form-control' id='mrk1-". $i."'>
				</div>
			</div>

");

echo "<br>";
}

?>
			<br>
			<h3 style="color: white">Question 2.</h3><br>
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<textarea name="title2" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
				</div>
			</div><br>
			<?php 

for($i=1;$i<=2;$i++){
	print("
<div class='row'>

				<div class='col-sm-2'>
					<select class='form-control' name='qno2-".$i."' id='qno2-".$i."'>
						<option value=''>--</option>
						<option value='2a'>2a</option>
						<option value='2b'>2b</option>
						<option value='2c'>2c</option>
						<option value='2d'>2d</option>					
					</select>
				</div>
				<div class='col-sm-2'>

					<select class='form-control' id='co2-".$i."' name='co2-".$i."'>
						<option value=''>--</option>
						<option value='1'>CO1</option>
						<option value='2'>CO2</option>
						<option value='3'>CO3</option>
						<option value='4'>CO4</option>
						<option value='5'>CO5</option>
						<option value='6'>CO6</option>
					</select>

				</div>
				<div class='col-sm-6'>
					<textarea class='form-control' name='quest2-".$i."' id='quest2-".$i."' placeholder='question'></textarea>
					<ul class='result' id='result2-".$i."'>

					</ul>
				</div>
				<div class='col-sm-1'>
					<input type='text' name='mrk2-".$i."' class='form-control' id='mrk2-". $i."'>
				</div>
			</div>

");

echo "<br>";
}
			?>

			<br>
			<h3 style="color: white">Question 3.</h3><br>
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<textarea name="title3" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
				</div>
			</div><br>
			<?php 

for($i=1;$i<=2;$i++){
	print("
<div class='row'>

				<div class='col-sm-2'>
					<select class='form-control' name='qno3-".$i."' id='qno3-".$i."'>
						<option value=''>--</option>
						<option value='3a'>3a</option>
						<option value='3b'>3b</option>
						<option value='3c'>3c</option>
						<option value='3d'>3d</option>
					
					</select>
				</div>
				<div class='col-sm-2'>

					<select class='form-control' id='co3-".$i."' name='co3-".$i."'>
						<option value=''>--</option>
						<option value='1'>CO1</option>
						<option value='2'>CO2</option>
						<option value='3'>CO3</option>
						<option value='4'>CO4</option>
						<option value='5'>CO5</option>
						<option value='6'>CO6</option>
					</select>

				</div>
				<div class='col-sm-6'>
					<textarea class='form-control' name='quest3-".$i."' id='quest3-".$i."' placeholder='question'></textarea>
					<ul class='result' id='result3-".$i."'>

					</ul>
				</div>
				<div class='col-sm-1'>
					<input type='text' name='mrk3-".$i."' class='form-control' id='mrk3-". $i."'>
				</div>
			</div>

");

echo "<br>";
}
			?>
			<br><br>
			<div class="row">
				<div class="col-sm-6"></div>
				<div class="col-sm-6">
					<button id="submit" href="4.php" class="btn btn-danger " name="submit">Submit</button>
				</div>
				<div class="col-sm-6"></div>
			</div>
		</div>
	</form>
	<br>
	<br>
	<br>

	<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
	<!--<script src='//code.jquery.com/jquery-1.11.2.min.js'></script>-->
	<script src='../js/jquery-1.11.0.min.js'></script>

	<script>
		$(document).ready(function() {


			<?php 	
	for($i=1;$i<=5;$i++){		
print("

			$('#co1-". $i."').keyup(function() {
				var co = $('#co1-". $i." option:selected').val();
				$.ajax({
					url: '2.php',
					data: {
						co: co,
						no: '1-".$i."'
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result1-". $i."').html(data).show();
						}
					}
				});
			});

			$('#quest1-". $i."').keyup(function() {
				var quest = $('#quest1-". $i."').val();
				$.ajax({
					url: '3.php',
					data: {
						quest: quest,
						
						no: '1-".$i."'
						
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result1-". $i."').html(data).show();
							
						}
					}
				});
			});

");
	}
					
				for($i=1;$i<=2;$i++){		
print("
			$('#co2-". $i."').keyup(function() {
				var co = $('#co2-". $i." option:selected').val();
				$.ajax({
					url: '2.php',
					data: {
						co: co,
						no: '2-".$i."'
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result2-". $i."').html(data).show();
						}
					}
				});
			});

			$('#quest2-". $i."').keyup(function() {
				var quest = $('#quest2-". $i."').val();
				$.ajax({
					url: '3.php',
					data: {
						quest: quest,
						no: '2-".$i."'
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result2-". $i."').html(data).show();
							
						}
					}
				});
			});

");
	}






for($i=1;$i<=2;$i++){		
print("
			$('#co3-". $i."').keyup(function() {
				var co = $('#co3-". $i." option:selected').val();
				$.ajax({
					url: '2.php',
					data: {
						co: co,
						no: 3-".$i."
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result3-". $i."').html(data).show();
						}
					}
				});
			});

			$('#quest3-". $i."').keyup(function() {
				var quest = $('#quest3-". $i."').val();
				$.ajax({
					url: '3.php',
					data: {
						quest: quest,
						no: 3-".$i."
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result3-". $i."').html(data).show();
							
						}
					}
				});
			});

");
	}


		?>


		});


		function fill(Value, NO) {


			$('#quest' + NO).val(Value);
			$('#result' + NO).hide();


		}

	</script>

</body>

</html>
