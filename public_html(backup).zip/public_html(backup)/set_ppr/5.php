<?php 

ob_start();
session_start();
if(!empty($_POST['title1'])){
	 $title1 = $_POST['title1'];
	}else{
		$title1 = 'not entered';
	}
	if(!empty($_POST['edate'])){
	 $edate = date('d/m/Y', strtotime($_POST['edate']));
	}else{
		$edate = 'Date is not entered';
	}
	if(!empty($_POST['esub'])){
	  $esub = $_POST['esub'];
	}else{
		 $esub = 'Subject no entered';
	}
	if(!empty($_POST['etime'])){
		 $etime = $_POST['etime'];
	}else{
		$etime = 'Time not entered';
	}
$qno1 = array();
$co1 = array();
$quest1 = array();
$mrk1 = array();
for( $i=1;$i<=5;$i++){
if(!empty($_POST['qno1-'.(string)  $i])){
		 $qno = array($_POST['qno1-'.(string) $i]);
		 $qno1 = array_merge($qno,$qno1);	
	}else{
		$qno = array('quest no '.(string) $i.' not entered');
	 	$qno1 = array_merge($qno,$qno1);
	}
	
	if(!empty($_POST['co1-'.(string) $i])){
		$co = array($_POST['co1-'.(string) $i]);
		$co1 = array_merge($co,$co1);
	}else{
		$co = array('co '.(string) $i.' not entered');
		$co1 = array_merge($co,$co1);
	}
	
	if(!empty($_POST['quest1-'.(string) $i])){
		$quest = array($_POST['quest1-'.(string) $i]); 
		$quest1 = array_merge($quest,$quest1);
	}else{
		$quest = array('quest '.(string) $i.' not entered ');
		$quest1 = array_merge($quest,$quest1);
	}
	
	if(!empty($_POST['mrk1-'.(string) $i])){
		$mrk = array($_POST['mrk1-'.(string) $i]);
		$mrk1 = array_merge($mrk,$mrk1);
	}else{
		$mrk = array('mark no '.(string) $i.' not enntered');
		$mrk1 = array_merge($mrk,$mrk1);
	}
	
}
array_reverse($qno1,true);
array_reverse($quest1);
array_reverse($mrk1);
array_reverse($co1);
print_r($qno1);
echo "<br>";
print_r($quest1);
echo "<br>";
print_r($mrk1);
echo "<br>";
print_r($co1);
echo "<br>";
?>







<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='UTF-8'>
	<title>Document</title>
	<style>
	
		
		th{
			font-size: 1.1em;
		}
		th.qno{
			margin-right: 0;
			padding-left: 0;
		}
		th.quest{
			margin-left: 0;
			padding-left: 0;
		}
	</style>
</head>
<body>
<div id='HTMLtoPDF'>
<b>
	<h1 style='text-align: center'><b>F.C.R.I.T. Question paper manager</b></h1>
	<br>
	
	<h3>
		<?php echo $edate; ?><br>
		<?php echo $esub; ?><br>
		<?php echo $etime; ?><br>
	</h3>
	<h4><?php echo $title1; ?></h4>
	<div>
		<?php echo $qno; ?>&nbsp;&nbsp;&nbsp;<?php echo $quest; ?>&nbsp;&nbsp;&nbsp;
		<?php echo $mrk1; ?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CO &nbsp;<?php echo $co1;?>
		
	</div>
		
</b>



<table >

<?php echo $i;
	
	for($j=4;$j>=0;$j--){
		echo "<tr>";
		
		echo "<th class='qno'>$qno1[$j]</th>";
		echo "<th class='quest'>$quest1[$j]</th>";
		echo "<th class='mrk'>$mrk1[$j]</th>";
		echo "<th class='co'>$co1[$j]</th>";
		echo "	</tr>";
	}
		?>
	
		
		
	
		

</table>

	</div>
	
	<button onclick='HTMLtoPDF()' >submit</button>
	
	<script src='../js/jspdf.js'></script>
	<script src='../js/jquery-2.1.3.js'></script>
	<script src='../js/pdfFromHTML.js'></script>
	<script>
	
		
	</script>
</body>
</html>



