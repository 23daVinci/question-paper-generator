<?php session_start();
if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}

?>
<?php

if(isset($_POST['submit'])){
    
    
    
}

?>


<?php 

ob_start();

if(!empty($_POST['title1'])){
	 $title1 = $_POST['title1'];
	}else{
		$title1 = 'not entered';
	}


if(!empty($_POST['title2'])){
	 $title2 = $_POST['title2'];
	}else{
		$title2 = 'not entered';
	}
	
if(!empty($_POST['title3'])){
	 $title3 = $_POST['title3'];
	}else{
		$title3 = 'not entered';
	}

if(!empty($_POST['title4'])){
	 $title4 = $_POST['title4'];
	}else{
		$title4 = 'not entered';
	}

if(!empty($_POST['title5'])){
	 $title5 = $_POST['title5'];
	}else{
		$title5 = 'not entered';
	}

if(!empty($_POST['title6'])){
	 $title6 = $_POST['title6'];
	}else{
		$title6 = 'not entered';
	}



$qno1 = array();
$co1 = array();
$quest1 = array();
$mrk1 = array();
for( $i=1;$i<=5;$i++){
if(!empty($_POST['qno1-'.(string)  $i])){
		 $qno = array($_POST['qno1-'.(string) $i]);
		 $qno1 = array_merge($qno,$qno1);	
	}else{
		$qno = array("");
		$qno1 = array_merge($qno,$qno1);	
}
	
	if(!empty($_POST['co1-'.(string) $i])){
		$co = array($_POST['co1-'.(string) $i]);
		$co1 = array_merge($co,$co1);
	}else{
		$co = array("");
		$co1 = array_merge($co,$co1);
	}
	
	if(!empty($_POST['quest1-'.(string) $i])){
		$quest = array($_POST['quest1-'.(string) $i]); 
		$quest1 = array_merge($quest,$quest1);
	}else{
		$quest = array(""); 
		$quest1 = array_merge($quest,$quest1);
	}
	
	if(!empty($_POST['mrk1-'.(string) $i])){
		$mrk = array($_POST['mrk1-'.(string) $i]);
		$mrk1 = array_merge($mrk,$mrk1);
	}else{
		$mrk = array("");
		$mrk1 = array_merge($mrk,$mrk1);
	}
	
}





$qno2 = array();
$co2 = array();
$quest2 = array();
$mrk2 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno2-'.(string)  $i])){
		 $qno = array($_POST['qno2-'.(string) $i]);
		 $qno2 = array_merge($qno,$qno2);	
	}else{
		$qno = array("");
		$qno2 = array_merge($qno,$qno2);	
}
	
	if(!empty($_POST['co2-'.(string) $i])){
		$co = array($_POST['co2-'.(string) $i]);
		$co2 = array_merge($co,$co2);
	}else{
		$co = array("");
		$co2 = array_merge($co,$co2);
	}
	
	if(!empty($_POST['quest2-'.(string) $i])){
		$quest = array($_POST['quest2-'.(string) $i]); 
		$quest2 = array_merge($quest,$quest2);
	}else{
		$quest = array(""); 
		$quest2 = array_merge($quest,$quest1);
	}
	
	if(!empty($_POST['mrk2-'.(string) $i])){
		$mrk = array($_POST['mrk2-'.(string) $i]);
		$mrk2 = array_merge($mrk,$mrk2);
	}else{
		$mrk = array("");
		$mrk2 = array_merge($mrk,$mrk2);
	}
	
}

$qno3 = array();
$co3 = array();
$quest3 = array();
$mrk3 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno3-'.(string)  $i])){
		 $qno = array($_POST['qno3-'.(string) $i]);
		 $qno3 = array_merge($qno,$qno3);	
	}else{
		$qno = array("");
		$qno3 = array_merge($qno,$qno3);	
}
	
	if(!empty($_POST['co3-'.(string) $i])){
		$co = array($_POST['co3-'.(string) $i]);
		$co3 = array_merge($co,$co3);
	}else{
		$co = array("");
		$co3 = array_merge($co,$co3);
	}
	
	if(!empty($_POST['quest3-'.(string) $i])){
		$quest = array($_POST['quest3-'.(string) $i]); 
		$quest3 = array_merge($quest,$quest3);
	}else{
		$quest = array(""); 
		$quest3 = array_merge($quest,$quest3);
	}
	
	if(!empty($_POST['mrk3-'.(string) $i])){
		$mrk = array($_POST['mrk3-'.(string) $i]);
		$mrk3 = array_merge($mrk,$mrk3);
	}else{
		$mrk = array("");
		$mrk3 = array_merge($mrk,$mrk3);
	}
	
}

$qno4 = array();
$co4 = array();
$quest4 = array();
$mrk4 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno4-'.(string)  $i])){
		 $qno = array($_POST['qno4-'.(string) $i]);
		 $qno4 = array_merge($qno,$qno4);	
	}else{
		$qno = array("");
		$qno4 = array_merge($qno,$qno4);	
}
	
	if(!empty($_POST['co4-'.(string) $i])){
		$co = array($_POST['co4-'.(string) $i]);
		$co4 = array_merge($co,$co4);
	}else{
		$co = array("");
		$co4 = array_merge($co,$co4);
	}
	
	if(!empty($_POST['quest4-'.(string) $i])){
		$quest = array($_POST['quest4-'.(string) $i]); 
		$quest4 = array_merge($quest,$quest4);
	}else{
		$quest = array(""); 
		$quest4 = array_merge($quest,$quest4);
	}
	
	if(!empty($_POST['mrk4-'.(string) $i])){
		$mrk = array($_POST['mrk4-'.(string) $i]);
		$mrk4 = array_merge($mrk,$mrk4);
	}else{
		$mrk = array("");
		$mrk4 = array_merge($mrk,$mrk4);
	}
	
}


$qno5 = array();
$co5 = array();
$quest5 = array();
$mrk5 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno5-'.(string)  $i])){
		 $qno = array($_POST['qno5-'.(string) $i]);
		 $qno5 = array_merge($qno,$qno5);	
	}else{
		$qno = array("");
		$qno5 = array_merge($qno,$qno5);	
}
	
	if(!empty($_POST['co5-'.(string) $i])){
		$co = array($_POST['co5-'.(string) $i]);
		$co5 = array_merge($co,$co5);
	}else{
		$co = array("");
		$co5 = array_merge($co,$co5);
	}
	
	if(!empty($_POST['quest5-'.(string) $i])){
		$quest = array($_POST['quest5-'.(string) $i]); 
		$quest5 = array_merge($quest,$quest5);
	}else{
		$quest = array(""); 
		$quest5 = array_merge($quest,$quest5);
	}
	
	if(!empty($_POST['mrk5-'.(string) $i])){
		$mrk = array($_POST['mrk5-'.(string) $i]);
		$mrk5 = array_merge($mrk,$mrk5);
	}else{
		$mrk = array("");
		$mrk5 = array_merge($mrk,$mrk5);
	}
	
}

$qno6 = array();
$co6 = array();
$quest6 = array();
$mrk6 = array();
for( $i=1;$i<=2;$i++){
if(!empty($_POST['qno6-'.(string)  $i])){
		 $qno = array($_POST['qno6-'.(string) $i]);
		 $qno6 = array_merge($qno,$qno6);	
	}else{
		$qno = array("");
		$qno6 = array_merge($qno,$qno6);	
}
	
	if(!empty($_POST['co6-'.(string) $i])){
		$co = array($_POST['co6-'.(string) $i]);
		$co6 = array_merge($co,$co6);
	}else{
		$co = array("");
		$co6 = array_merge($co,$co6);
	}
	
	if(!empty($_POST['quest6-'.(string) $i])){
		$quest = array($_POST['quest6-'.(string) $i]); 
		$quest6 = array_merge($quest,$quest6);
	}else{
		$quest = array(""); 
		$quest6 = array_merge($quest,$quest6);
	}
	
	if(!empty($_POST['mrk6-'.(string) $i])){
		$mrk = array($_POST['mrk6-'.(string) $i]);
		$mrk6 = array_merge($mrk,$mrk6);
	}else{
		$mrk = array("");
		$mrk6 = array_merge($mrk,$mrk6);
	}
	
}
/*array_reverse($qno1,true);
array_reverse($quest1);
array_reverse($mrk1);
array_reverse($co1);
print_r($qno1);
echo "<br>";
print_r($quest1);
echo "<br>";
print_r($mrk1);
echo "<br>";
print_r($co1);
echo "<br>";*/
// print_r($co1);
// print_r($qno1);
?>







<!DOCTYPE html>
<html lang='en'>

<head>

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title>QBank</title>
    <style>
        @font-face {
            font-family: 'MyWebFont';
            src: url('../fonts/alsscrp.ttf') format('truetype');

        }

        html,
        body {
            max-width: 100%;
            overflow-x: hidden;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background-color: white;
        }

        .topnav {
            overflow: hidden;
            background-color: #141414;
        }
        
        td{
            font-family: "Times New Roman", Times, serif;
        }

        .topnav a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        .topnav a:hover {
            background-color: rgba(239, 233, 233, 0.54);
            color: black;
        }

        .active {
            background-color: #4fea55;
            color: black;
        }

        .topnav .icon {
            display: none;
        }

        .logo {
            position: relative;
            left: 150px;
            top: -30px;
        }

        @media screen and (max-width: 600px) {
            .topnav a:not(:first-child) {
                display: none;
            }

            .topnav a.icon {
                float: right;
                display: block;
            }
        }

        @media screen and (max-width: 600px) {
            .topnav.responsive {
                position: relative;
            }

            .topnav.responsive .icon {
                position: absolute;
                right: 0;
                top: 0;
            }

            .topnav.responsive a {
                float: none;
                display: block;
                text-align: left;
            }
        }


        th {
            font-size: 1.1em;
        }

        th.qno {
            margin-right: 0;
            padding-left: 0;
        }

        th.quest {
            margin-left: 0;
            padding-left: 0;
        }

    </style>
</head>

<body>
    <div class="topnav" id="myTopnav">
        <a href="" class="active"><b>ELiT</b></a>
        <a href="../admin/index.php"><b>Dashboard</b></a>
        <a href="../admin/prev_ppr.php"><b>Previous papers</b></a>
        <a href="../admin/calendar.php"><b>Planner</b></a>
        <a href="../login/logout.php"><b>Logout</b></a>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <i class="fa fa-bars"></i>
        </a>
    </div>
    <div id='printableArea'>
        <!-- Image -->
        <img src="logo.png" width="55px" style="position: relative; left: 30px;" alt="">

        <!-- Name of the college -->
        <div class="row">
            <div class="col-sm-12">
                <p style="text-align: center;position: relative; top: -35px; font-family: 'MyWebFont'; font-size: 30px"><b>Fr. Conceicao Rodrigues Institute of Technology</b></p>
            </div>

            <!-- Exam name & Session name -->
            <div class="col-sm-12">
                <p style='text-align: center; position: relative; top: -60px; font-family: "Times New Roman", Times, serif; font-size: 18px;'><b>
                        <?php echo $_SESSION['etype']; ?></b></p>
                <?php 
                        $half = $_SESSION['edate'];
                        $split = explode("/", $half);
                        $day = $split[0];
                        $month = $split[1];
                        $year = $split[2];
                        if($month >= "7" || $month <= "4"){
                            echo "<p style='text-align: center; position: relative; top: -70px; font-size: 12px; font-family: 'Times New Roman', Times, serif;'><b>First half of " . $year . "</b></p>";
                        }
                        else{
                            echo "<p style='text-align: center; position: relative; top: -70px; font-family: 'Times New Roman', Times, serif; font-size: 12px;'><b>Second half of " . $year . "</b></p>";
                        }
                    ?>
            </div>
        </div>

        <!-- Exam details -->
        <div class="row">
            <!-- Subject -->
            <div class="col-sm-2">
                <p style='font-family: "Times New Roman", Times, serif; position: relative; top: -80px;'><b>
                        <?php echo "Subject: " .  $_SESSION['sub']; ?></b></p>
                <p style='font-family: "Times New Roman", Times, serif; position: relative; top: -80px;'><b>
                        <?php echo "Branch: " .  $_SESSION['branch']."-".$_SESSION['sem']; ?></b></p>
                <p style='font-family: "Times New Roman", Times, serif; position: relative; left: 960px; top: -140px;'><b>
                        <?php echo "Time: " .  $_SESSION['time']; ?></b></p>
                <p style='font-family: "Times New Roman", Times, serif; position: relative; left: 960px; top: -140px;'><b>
                        <?php echo "Total marks: " .  $_SESSION['marks']; ?></b></p>
            </div>
        </div>



        <!-- Note -->
        <div class="row">
            <div class="col-sm-12">
                <p style="position: relative; top: -120px;"><u>note</u>: Figures to the right indicate <span style="color: red"><u>C: co number</u></span> and <span style="color: red"><u>M: marks</u></span> respectively.</p>
            </div>
        </div>


        <!-- Question no. 1 -->
        <div class="row">
            <div class="col-sm-12">
                <p style='font-family: "Times New Roman", Times, serif; font-size: 15px; position: relative; top: -120px; left: 20px'><b>
                        <?php echo "Q1. " . $title1; ?></b></p>
            </div>
        </div>

        <table class="table" style="position: relative; top: -120px; left: 20px;">
            <?php 
	for($j=4;$j>=0;$j--){
	
		echo "<tr>";
		echo "<td class='qno' width='3%'>$qno1[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest' width='80%'>$quest1[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co' width = '7%'>[C $co1[$j]]</td>";
		echo "<td class='mrk' width = '10%'>[M $mrk1[$j]]&nbsp;&nbsp;&nbsp;</td>";
		echo"</tr>";
		
	}
		?>
        </table>



        <p style='font-family: "Times New Roman", Times, serif; font-size: 15px; position: relative; top: -120px; left: 20px'><b>
                <?php echo "Q2. " . $title2; ?></b></p>



        <table class="table" style="position: relative; top: -120px; left: 20px;">

            <?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<td class='qno' width = '3%'>$qno2[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest' width = '80%'>$quest2[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co' width = '7%'>[C $co2[$j]]</td>";
		echo "<td class='mrk' width = 10%'>[M $mrk2[$j]]&nbsp;&nbsp;&nbsp;</td>";
		
		echo "	</tr>";
	}
		?>


        </table>


                                <!-- question no. 3 -->
        <p style='font-family: "Times New Roman", Times, serif; font-size: 15px; position: relative; top: -120px; left: 20px'><b>
                <?php echo "Q3. " . $title3; ?></b></p>



        <table class="table" style="position: relative; top: -120px; left: 20px;">

            <?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<td class='qno' width = '3%'>$qno3[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest' width = '80%'>$quest3[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co' width = '7%'>[C $co3[$j]]</td>";
		echo "<td class='mrk' width = '10%'>[M $mrk3[$j]]&nbsp;&nbsp;&nbsp;</td>";
		
		echo "	</tr>";
	}
		?>


        </table>
        
        
                               <!-- question no. 4 -->
        <p style='font-family: "Times New Roman", Times, serif; font-size: 15px; position: relative; top: -120px; left: 20px'><b>
                <?php echo "Q4. " . $title4; ?></b></p>



        <table class="table" style="position: relative; top: -120px; left: 20px;">

            <?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<td class='qno' width = '3%'>$qno4[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest' width = '80%'>$quest4[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co' width = '7%'>[C $co4[$j]]</td>";
		echo "<td class='mrk' width = '10%'>[M $mrk4[$j]]&nbsp;&nbsp;&nbsp;</td>";
		
		echo "	</tr>";
	}
		?>


        </table>
        
                               <!-- question no. 5 -->
        <p style='font-family: "Times New Roman", Times, serif; font-size: 15px; position: relative; top: -120px; left: 20px'><b>
                <?php echo "Q5. " . $title4; ?></b></p>



        <table class="table" style="position: relative; top: -120px; left: 20px;">

            <?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<td class='qno' width = '3%'>$qno5[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest' width = '80%'>$quest5[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co' width = '7%'>[C $co5[$j]]</td>";
		echo "<td class='mrk' width = '10%'>[M $mrk5[$j]]&nbsp;&nbsp;&nbsp;</td>";
		
		echo "	</tr>";
	}
		?>


        </table>

                               <!-- question no. 6 -->
        <p style='font-family: "Times New Roman", Times, serif; font-size: 15px; position: relative; top: -120px; left: 20px'><b>
                <?php echo "Q6. " . $title4; ?></b></p>



        <table class="table" style="position: relative; top: -120px; left: 20px;">

            <?php 
	for($j=1;$j>=0;$j--){
		echo "<tr>";
		
		echo "<td class='qno' width = '3%'>$qno6[$j]&nbsp;&nbsp;&nbsp;</td>";
		echo "<td class='quest' width = '80%'>$quest6[$j] &nbsp;&nbsp;&nbsp;&nbsp;&nbsp</td>";
		echo "<td class='co' width = '7%'>[C $co6[$j]]</td>";
		echo "<td class='mrk' width = '10%'>[M $mrk6[$j]]&nbsp;&nbsp;&nbsp;</td>";
		
		echo "	</tr>";
	}
		?>


        </table>

        <p style="text-align: center">---------------------------------------------------------------all the best!-------------------------------------------------------------------</p>


    </div>
    <br>
    <br>
    <br>
    <br>
    <form action="" method="post">
        <button class="btn btn-primary" onclick="printDiv('printableArea')" name="submit" style="position: relative; left: 800px">submit</button>
    </form>
    <br>
    <br>
    <br>
    <script>
        function printDiv(divName) {
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;

            document.body.innerHTML = printContents;

            window.print();

            document.body.innerHTML = originalContents;
        }

    </script>

    <script src='../js/jspdf.js'></script>
    <script src='../js/jquery-2.1.3.js'></script>
    <script src='../js/pdfFromHTML.js'></script>
    <script>


    </script>
</body>

</html>
