<?php 
ob_start();
session_start();
include("../includes/db.php");
include("../includes/function.php");


$id = implode(',',$_SESSION['id']);
 if(isset($_POST['quest'])){
		
		 $quest = $_POST['quest'];
		 $no = $_POST['no'];
$query = "Select * from it where  id in(".$id.") and quest like '%".$quest."%' ";
$result = mysqli_query($conn,$query);
		
while($row = mysqli_fetch_assoc($result)){
	$id = $row['id'];
	$quest = $row['quest'];
	?>
	
	<li onclick="fill('<?php echo $quest; ?>','<?php echo $no; ?>')"><a><?php echo $quest; ?></a></li>
	
	<?php
	
}		
}else{
	 echo "not quest";
 }


?>





