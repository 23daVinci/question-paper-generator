<!DOCTYPE html>

<html lang='en'>

<head>

	<meta charset='UTF-8'>

	<title>Document</title>
	<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>

	<style>
		* {
  box-sizing: border-box;
}

#myInput {
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

.result {
  list-style-type: none;
  padding: 0;
  margin: 0;
  margin-top:-12px;
}

.result li a {
  border: 1px solid #ddd;
  margin-top: -1px; /* Prevent double borders */
  background-color: #f6f6f6;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  color: black;
  display: block
}

.result li a:hover:not(.header) {
  background-color: #eee;
}

	</style>
</head>

<body>


	<br>
	<form action="5.php" method="post">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h1 style="text-align: center"><b>F.C.R.I.T. Question paper manager</b></h1>
					<br>
					<br>
				</div>
			</div>

			<div class="row">
				<div class="col-sm-4">
					<label for="">exam date: </label>
					<input class="form-control" type="date" name="edate">
				</div>
				<div class="col-sm-4">
					<label for="">Duration: </label>
					<input class="form-control" type="text" name="etime">
				</div>
				<div class="col-sm-4">
					<label for="">Subject: </label>
					<input class="form-control" type="text" name="esub">
				</div>
			</div>

			<!-- paper entry -->

			<br>
			<h3>Question 1.</h3><br>
			<div class="row">
				<div class="col-md-6 col-sm-12">
					<textarea name="title1" class="form-control" id="" cols="15" rows="2" placeholder="Question title"></textarea>
				</div>
			</div><br>
<?php 

for($i=1;$i<=5;$i++){
	print("
<div class='row'>

				<div class='col-sm-2'>
					<select class='form-control' name='qno1-".$i."' id='qno1-".$i."'>
						<option value=''>--</option>
						<option value='1a'>1a</option>
						<option value='1b'>1b</option>
						<option value='1c'>1c</option>
						<option value='1d'>1d</option>
						<option value='1e'>1e</option>
						<option value='1f'>1f</option>
						<option value='1g'>1g</option>
					</select>
				</div>
				<div class='col-sm-2'>

					<select class='form-control' id='co1-".$i."' name='co1-".$i."'>
						<option value='Not Entered'>--</option>
						<option value='1'>CO1</option>
						<option value='2'>CO2</option>
						<option value='3'>CO3</option>
						<option value='4'>CO4</option>
						<option value='5'>CO5</option>
						<option value='6'>CO6</option>
					</select>

				</div>
				<div class='col-sm-6'>
					<textarea class='form-control' name='quest1-".$i."' id='quest1-".$i."' placeholder='question'></textarea>
					<ul class='result' id='result".$i."'>

					</ul>
				</div>
				<div class='col-sm-1'>
					<input type='text' name='mrk1-".$i."' class='form-control' id='mrk1-". $i."'>
				</div>
			</div>

");

echo "<br>";
}

?>
<br><br>
			<div class="row">
				<div class="col-sm-6"></div>
				<div class="col-sm-6">
					<button id="submit" href="4.php" class="btn btn-primary " name="submit">Submit</button>
				</div>
				<div class="col-sm-6"></div>
			</div>
		</div>
	</form>
	<br>
	<br>
	<br>

	<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js'></script>
	<script src='//code.jquery.com/jquery-1.11.2.min.js'></script>

<script>
		$(document).ready(function() {


	<?php 	
	for($i=1;$i<=5;$i++){		
print("
			$('#co1-". $i."').keyup(function() {
				var co = $('#co1-". $i." option:selected').val();
				$.ajax({
					url: '2.php',
					data: {
						co: co,
						no: ". $i."
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result". $i."').html(data).show();
						}
					}
				});
			});

			$('#quest1-". $i."').keyup(function() {
				var quest = $('#quest1-". $i."').val();
				$.ajax({
					url: '3.php',
					data: {
						quest: quest,
						no: ". $i."
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result". $i."').html(data).show();
							
						}
					}
				});
			});

");
	}

		?>

			/*$('#co1-2').keyup(function() {
				var co = $('#co1-2 option:selected').val();
				$.ajax({
					url: '2.php',
					data: {
						co: co,
						no: 2
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result2').html(data).show();
						}
					}
				});
			});

			$('#quest1-2').keyup(function() {
				var quest = $('#quest1-2').val();
				$.ajax({
					url: '3.php',
					data: {
						quest: quest,
						no: 2
					},
					type: 'POST',
					success: function(data) {
						if (!data.error) {
							$('#result2').html(data).show();
							
						}
					}
				});
			});

		});
*/


			});
	function fill(Value, NO) {


			$('#quest1-' + NO).val(Value);


			$('#result' + NO).hide();

		}

	</script>

</body>

</html>


