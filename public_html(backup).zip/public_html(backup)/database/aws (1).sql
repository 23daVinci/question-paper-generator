-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2019 at 01:32 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aws`
--

-- --------------------------------------------------------

--
-- Table structure for table `it`
--

CREATE TABLE `it` (
  `id` int(255) NOT NULL,
  `sem` varchar(255) NOT NULL,
  `sub` varchar(255) NOT NULL,
  `quest` varchar(255) NOT NULL,
  `co` varchar(255) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `it`
--

INSERT INTO `it` (`id`, `sem`, `sub`, `quest`, `co`, `image`) VALUES
(1, '5', 'CNS', 'What is CNS?', '1', 0x6665642e6a7067),
(2, '5', 'MEP', 'What is MEP?', '1', 0x6a61727669732e706e67),
(4, '5', 'CNS', 'What is ARP spoofing?', '2', ''),
(5, '5', 'CNS', 'what ans does sir wants?', '3', 0x32303138303833305f3232303835302d6d696e2e6a7067),
(6, '5', 'CNS', 'what is snort?', '1', ''),
(7, '5', 'CNS', 'what is dos?', '1', ''),
(8, '5', 'MEP', 'WHAT IS EMBEDDED SYSTEM', '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `newppr`
--

CREATE TABLE `newppr` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ttlQues` int(255) NOT NULL,
  `ttlMarks` int(255) NOT NULL,
  `que1_title` varchar(255) NOT NULL,
  `q1_sq1` varchar(255) NOT NULL,
  `q1_sq2` varchar(255) NOT NULL,
  `q1_sq3` varchar(255) NOT NULL,
  `q1_sq4` varchar(255) NOT NULL,
  `q1_sq5` varchar(255) NOT NULL,
  `q1_sq6` varchar(255) NOT NULL,
  `q1_sq7` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newppr`
--

INSERT INTO `newppr` (`id`, `name`, `ttlQues`, `ttlMarks`, `que1_title`, `q1_sq1`, `q1_sq2`, `q1_sq3`, `q1_sq4`, `q1_sq5`, `q1_sq6`, `q1_sq7`) VALUES
(1, 'yo', 3, 80, '', '', '', '', '', '', '', ''),
(2, 'yo', 3, 80, '', '', '', '', '', '', '', ''),
(27, 'more new', 1, 80, 'yyoyoyoyo', 'hello ppl', 'Hello World!', '', '', '', '', ''),
(28, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(29, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(30, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(31, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(32, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(33, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(34, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(35, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(36, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(37, 'super new', 1, 80, 'dvdfbdfb', 'hello', 'hello world', 'Hello world!', '', '', '', ''),
(38, 'Frooty', 1, 20, 'yoyo', 'yo1', 'yo2', '', '', '', '', ''),
(39, 'Frooty', 1, 20, 'yoyo', 'yo1', '', '', '', '', '', ''),
(40, 'frooty 2', 1, 80, 'huhuhuhu', 'jijijij', 'sjfhsd', '', '', '', '', ''),
(41, 'morest new', 1, 80, 'fsgsf', 'huhuhuhu', 'Hello World!', '', '', '', '', ''),
(42, 'Monali', 1, 80, 'Attempt any two of the  following questions.', 'what is my name?', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `prevpprs`
--

CREATE TABLE `prevpprs` (
  `id` int(255) NOT NULL,
  `year` int(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `sem` int(255) NOT NULL,
  `sub` varchar(255) NOT NULL,
  `exam` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `size` int(255) NOT NULL,
  `downloads` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prevpprs`
--

INSERT INTO `prevpprs` (`id`, `year`, `branch`, `sem`, `sub`, `exam`, `name`, `size`, `downloads`) VALUES
(1, 2015, 'it', 5, 'cns', 'ut', 'PiTextReader.pdf', 1017900, 0),
(4, 2018, 'comps', 7, 'cj', 'ut', 'PiTextReader.pdf', 1017900, 0),
(5, 2017, 'it', 5, 'cns', 'ut', 'PiTextReader.pdf', 1017900, 0),
(6, 2017, 'it', 5, 'mep', 'ut', 'PiTextReader.pdf', 1017900, 0),
(7, 2018, 'comps', 5, 'aa', 'ut', 'PiTextReader.pdf', 1017900, 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `fname`, `lname`, `email`, `password`) VALUES
(1, 'ashwin', 'thomas', 'ashwin', '$2y$10$ypBMcJHHhLebro93XPz/R.pnq6Z13prsFf9vDsvdXqX6h.PRCTlGG');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `branch` varchar(10) NOT NULL,
  `prefix` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `fname`, `lname`, `email`, `password`, `branch`, `prefix`, `image`) VALUES
(1, 'Purvesh', 'jain', 'jainpurvesh19@gmail.com', '$2y$10$K9wYvMy/0yggsq/3jSmL9OywKJEI4lzzGi1.pFGrkKEfZePWth9p6', 'IT', '', ''),
(2, 'ashwin', 'thomas', 'thomas@gmail.com', 'papAq5PwY/QQM', 'EXTC', 'Mr.', 'ashwin.png'),
(4, 'naman', 'lazarus', 'Naman', 'papAq5PwY/QQM', 'IT', 'Mr.', 'naman.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `it`
--
ALTER TABLE `it`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newppr`
--
ALTER TABLE `newppr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prevpprs`
--
ALTER TABLE `prevpprs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `it`
--
ALTER TABLE `it`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `newppr`
--
ALTER TABLE `newppr`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `prevpprs`
--
ALTER TABLE `prevpprs`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
