<?php 

//line no 11
$query = "SELECT SUM(`event_name`) AS total_stud FROM `events1` WHERE `event_name` = '$selected'";


?>