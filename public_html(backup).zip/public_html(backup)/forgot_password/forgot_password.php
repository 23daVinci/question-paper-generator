<?php 
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "aws";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $db);

    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    //echo "Connected successfully";

    if(isset($_POST['submit'])){
        $usrnm = $_POST['username'];
    }

?>


<html>

<head>
    <title>QBank</title>
    <?php include "includes/link.php"; ?>
    <style>
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover {
            background-color: #111;
        }
        
        #btn{
            position: relative;
            left: 100px;
        }

    </style>

</head>

<body>
    <ul>
        <li><a class="active" href="#home">Home</a></li>
        <li><a href="#news">News</a></li>
        <li><a href="#contact">Contact</a></li>
        <li><a href="#about">About</a></li>
    </ul>
    <div class="container">
        <br><br>
        <br><br>
        <div class="row">
            <div class="col-lg-4">
                <p> </p>
            </div>
            <div class="col-lg-4 jumbotron">
                <h3 style="text-align: center">Forgot Password</h3><br>
                <form action="" method="post">
                    <label for="">Username: </label>
                    <input type="text" class="form-control" name="username"><br>
                    <input type="submit" id="btn" class="btn btn-primary" name="submit" value="Submit">
                </form>
            </div>
            <div class="col-lg-4">
                <p> </p>
            </div>
        </div>
    </div>
</body>

</html>
