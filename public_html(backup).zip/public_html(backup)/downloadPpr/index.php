<?php
include "../includes/db.php";
if(isset($_POST['submit'])) {
    $branch = $_POST['branch'];
    $sem = $_POST['sem'];
    
    $query = "SELECT * FROM prevPprs WHERE `branch` = '$branch' AND `sem` = '$sem' ORDER BY sub AND year";
    $result = mysqli_query($conn, $query);
    $files = mysqli_fetch_all($result, MYSQLI_ASSOC);

    
}

// Downloads files
if(isset($_GET['file_id'])) {
    $id = $_GET['file_id'];

    // fetch file to download from database
    $sql1 = "SELECT * FROM prevpprs WHERE `id` = '$id' ";
    $result1 = mysqli_query($conn, $sql1);

    $file = mysqli_fetch_assoc($result1);
    $filepath = '../../admin/uploads/' . $file['name'];

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize('../../admin/uploads/' . $file['name']));
        readfile('../../admin/uploads/' . $file['name']);

        exit;
    }

}

?>
<!DOCTYPE html>
<html>

<head>
    <title>QBank</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        body {
            background-image: url("../img/bg-img/welcome-bg.png");
            background-repeat: no-repeat;
        }

    </style>
</head>

<body><br>
    <div class="container" style="background-color: rgba(255, 254, 254, 0.5)">
        <h1 style="text-align: center">Download Previous Question Papers</h1>
    </div>
    <br><br>
    <!-- form container -->
    <div class="container jumbotron" style="background-color: rgba(255, 254, 254, 0.5)">
        <form action="" method="post">
            <div class="row">
                <div class="col-sm-2">
                    <p> </p>
                </div>
                <div class="col-sm-3">
                    <p>Branch:</p>
                    <select class="form-control" name="branch" id="">
                        <option value="humanities">Humanities</option>
                        <option value="it">I.T.</option>
                        <option value="comps">Comps</option>
                        <option value="mech">Mech</option>
                        <option value="elec">Elec</option>
                        <option value="extc">EXTC</option>
                    </select>
                </div>
                <div class="col-sm-1">
                    <p> </p>
                </div>
                <div class="col-sm-3">
                    <p>Semester:</p>
                    <select class="form-control" name="sem" id="">
                        <option value="1">sem 1</option>
                        <option value="2">sem 2</option>
                        <option value="3">sem 3</option>
                        <option value="4">sem 4</option>
                        <option value="5">sem 5</option>
                        <option value="6">sem 6</option>
                        <option value="7">sem 7</option>
                        <option value="8">sem 8</option>
                    </select>
                </div>
            </div><br>
            <div class="row">
                <div class="col-sm-5">
                    <p> </p>
                </div>
                <div class="col-sm-2">
                    <input type="submit" name="submit" class="btn btn-primary">
                </div>
            </div>
        </form>
        <br>
        <!-- form query result -->
        <table class="table">
            <thead>
                <th>Subject</th>
                <th>Year</th>
                <th>Exam</th>
                <th>Filename</th>
                <th>size (in mb)</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php foreach ($files as $file): ?>
                <tr>
                    <td>
                        <?php echo $file['sub']; ?>
                    </td>
                    <td>
                        <?php echo $file['year']; ?>
                    </td>
                    <td>
                        <?php echo $file['exam']; ?>
                    </td>
                    <td>
                        <?php echo $file['name']; ?>
                    </td>
                    <td>
                        <?php echo floor($file['size'] / 1000) . ' KB'; ?>
                    </td>
                    <td><a href="index.php?file_id=<?php echo $file['id'] ?>">Download</a></td>
                </tr>
                <?php endforeach;?>

            </tbody>
        </table>

        <!-- form query result end -->
    </div>
    <!-- form container end -->
</body>

</html>
