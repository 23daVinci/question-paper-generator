<?php
session_start();

            $_SESSION['id'] = null;
			$_SESSION['fname'] = null;
            $_SESSION['lname'] = null;
            $_SESSION['doa'] = null;
            $_SESSION['address'] = null;
            $_SESSION['phone'] = null;
            $_SESSION['image'] = null;
 
header("Location: ../index.php");
 
  ?>