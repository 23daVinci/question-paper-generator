<?php
session_start();
session_unset();
session_destroy();

            $_SESSION['id'] = null;
			$_SESSION['fname'] = null;
            $_SESSION['lname'] = null;
            $_SESSION['doa'] = null;
            $_SESSION['address'] = null;
            $_SESSION['phone'] = null;
            $_SESSION['image'] = null;
 
header("Location: ../index.php");
exit();
 
  ?>
