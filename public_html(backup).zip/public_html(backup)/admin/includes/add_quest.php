<?php

$db['db_host']="localhost";
$db['db_user']="root";
$db['db_pass']="";
$db['db_name']="aws";
 
foreach($db as $key => $value){
	define(strtoupper($key),$value);
	
}
$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME);

include("function.php");
//if($conn) echo "conn";

 if(isset($_POST['add_quest'])){
                    $branch = $_POST['branch'];
                    $sem = $_POST['sem'];
                    $sub = $_POST['subject'];
                    $quest = $_POST['quest'];
                    $chap = $_POST['chap'];
                    $image = $_POST['qimg'];
                    $marks = $_POST['marks'];
     
                    $table = $branch.$sem;
     
     
                       $query = "INSERT INTO $table (sem, sub, chap, quest, marks, image) "; 
                       $query.="VALUES('$sem','$sub','$chap','$quest' ,'$marks' ,'$image')";
                        $result = mysqli_query($conn,$query);
                    
                        echo "Question added succesfully";
                        
                        if(!$result){
                            die('FAILED'.mysqli_error($conn));
                        }
     
                    }
         






?>
