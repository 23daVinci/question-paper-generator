<?php

include "../includes/db.php";
// Uploads files
if (isset($_POST['submit'])) { // if save button on the form is clicked
    $branch = $_POST['branch'];
    $year = $_POST['year'];
    $sem = $_POST['sem'];
    $exam = $_POST['exam'];
    $subject = $_POST['sub'];
    // name of the uploaded file
    $filename = $_FILES['ppr']['name'];

    // destination of the file on the server
    $destination = 'uploads/' . $filename;

    // get the file extension
    $extension = pathinfo($filename, PATHINFO_EXTENSION);

    // the physical file on a temporary uploads directory on the server
    $file = $_FILES['ppr']['tmp_name'];
    $size = $_FILES['ppr']['size'];

    if (!in_array($extension, ['zip', 'pdf', 'docx'])) {
        echo "You file extension must be .zip, .pdf or .docx";
    } elseif ($_FILES['ppr']['size'] > 3000000) { // file shouldn't be larger than 1Megabyte
        echo "File too large!";
    } else {
        // move the uploaded (temporary) file to the specified destination
        if (move_uploaded_file($file, $destination)) {
            $sql = "INSERT INTO prevpprs (year, branch, sem, sub, exam, name, size, downloads) VALUES ('$year', '$branch', '$sem', '$subject', '$exam','$filename', $size, 0)";
            if (mysqli_query($conn, $sql)) {
                echo "File uploaded successfully";
                
                    
            }
        } else {
            echo "<h1>";
            die("ERROR" . mysqli_error($conn));
            echo"</h1>";
        }
    }
}

?>