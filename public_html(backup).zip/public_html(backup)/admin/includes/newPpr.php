<?php session_start();

$conn = mysqli_connect("localhost","root","","aws");
if(mysqli_connect_error()){
	echo "error in connection";
}

if(isset($_POST['submit'])) {
    
    $pprName = $_POST['pprName'];
    $ttlMarks = $_POST['ttlMarks'];
    $ttlQues = $_POST['ttlQues'];
    // initial sending of data to the database
    $query = "INSERT INTO newppr (name, ttlQues, ttlMarks) VALUES('$pprName', '$ttlQues', '$ttlMarks')";
    $result = mysqli_query($conn, $query);
/*  if(!$result){
        die("Failed " . mysqli_error($conn));
    }
    else{
        echo "<h1>Successfully saved!!</h1>";
    } */
    
    // Query to get the id of the last entry in the table
    $lastIdQuery = "SELECT * FROM newppr ORDER BY id DESC LIMIT 1";
    $result2 = mysqli_query($conn, $lastIdQuery);
    $row = mysqli_fetch_array($result2);
    //echo $row['id'];
    $lastId = $row['id'];
    
    // further part of the form
    
    // Question no. 1
    $majQue1 = $_POST['majQue1']; // Title
    $subQue1 = $_POST['subQue1']; //no. of sub questions in Q.1
    $sq1_1 = $_POST['sq1_1']; // first question
    $sq1_1_mrks = $_POST['mrk_1'];
    // first subque insert query
    $query3 = "UPDATE newppr SET que1_title = '$majQue1', q1_sq1 = '$sq1_1', q1_sq1_mrks = '$sq1_1_mrks' WHERE id = '$lastId'";
    $result3 = mysqli_query($conn, $query3);
    /*if(!$result3){
        die("Failed " . mysqli_error($conn));
    }
    else{
        echo "<h1>Successfully saved!!</h1>";
    }*/
    // Updating the other sub questions
    if($subQue1 > 1){
        for ($c=2; $c<=$subQue1; $c++) {
            $something = "q1_sq" . $c;
            $somemrks = "q1_sq" . $c . "_mrks";
            $question = $_POST['sq1_' . $c];
            $marks = $_POST['mrk1_' . $c];
            $query4 = "UPDATE newppr SET $something = '$question', $somemrks = '$marks' WHERE id = '$lastId'";
            $result4 = mysqli_query($conn, $query4);
            if(!$result4){
                die("Failed " . mysqli_error($conn));
            }
        }
    }
    
    
    
    
}
?>
<html>

<head>
    <title>QBank</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body><br>
    <div class="container" style="background-color:#d3d3d2">
        <h1 style='text-align: center'>Thank You <span style='color:red'>Prof. <?php echo $_SESSION['firstname'];?></span></h1><br>
        
        <h2 style='text-align:center'>Your paper named <span style='color: blue'><?php echo $pprName; ?></span> with <span style='color: blue'><?php echo $ttlQues; ?> Questions</span> of total <span style='color:blue'><?php echo $ttlMarks; ?>  Marks</span> Has been saved successfully!!</h2><br>
        
        <form action="../viewNewPpr.php" method="post">
        <h4 style="text-align: center">Click to preview the paper.</h4>
        <input type="submit" name="submit" class="btn btn-primary" value="Preview">
        </form>
    </div>
</body>

</html>
