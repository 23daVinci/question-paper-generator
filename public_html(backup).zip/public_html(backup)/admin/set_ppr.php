<?php session_start();

if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="au theme template">
	<meta name="author" content="Hau Nguyen">
	<meta name="keywords" content="au theme template">

	<!-- Title Page-->
	<title></title>
		<!-- these js files are used for making PDF -->
	<script src="htmlToPdf/js/jspdf.js"></script>
	<script src="htmlToPdf/js/jquery-2.1.3.js"></script>
	<script src="htmlToPdf/js/pdfFromHTML.js"></script>

    <?php include "link.php"; ?>

	<!-- Main CSS-->
	<link href="css/theme.css" rel="stylesheet" media="all">
	
	<style>
    .box{
    padding:60px 0px;
}

.box-part{
    background:#FFF;
    border-radius:10px;
    padding:60px 10px;
    margin:30px 0px;
}

.box-part:hover{
    background:#4183D7;
}

.box-part:hover .fa , 
.box-part:hover .title , 
.box-part:hover .text ,
.box-part:hover a{
    color:#FFF;
    -webkit-transition: all 1s ease-out;
    -moz-transition: all 1s ease-out;
    -o-transition: all 1s ease-out;
    transition: all 1s ease-out;
}

.text{
    margin:20px 0px;
}

.fa{
     color:#4183D7;
}
    </style>
	<script>


  function generatePDF(){

  var conv = new ActiveXObject("pdfServMachine.converter");
  conv.convert("http://www.google.com", "c:\\google.pdf", false);
  WScript.Echo("finished conversion");
 }

 </script>

</head>

<body class="animsition">

	<div class="page-wrapper">
		<!-- HEADER MOBILE-->
		<header class="header-mobile d-block d-lg-none">
			<div class="header-mobile__bar">
				<div class="container-fluid">
					<div class="header-mobile-inner">
						<a class="logo" href="index.html">
							<img src="images/icon/logo.png" alt="CoolAdmin" />
						</a>
						<button class="hamburger hamburger--slider" type="button">
							<span class="hamburger-box">
								<span class="hamburger-inner"></span>
							</span>
						</button>
					</div>
				</div>
			</div>
			<nav class="navbar-mobile">
				<div class="container-fluid">
					<ul class="navbar-mobile__list list-unstyled">
						<li class="has-sub">
							<a class="js-arrow" href="index.php">
								<i class=""></i>Dashboard</a>
						</li>
						<li>
							<a href="quest_ppr.php">
								<i class=""></i>Question Paper</a>
						</li>
						<li>
                            <a href="prev_ppr.php">
                                <i class=""></i>Previous papers</a>
                        </li>
                        <li>
                            <a href="calendar.php">
                                <i class=""></i>Planner</a>
                        </li>
                        <li>
                            <a href="search.php">
                                <i class=""></i>Google</a>
                        </li>

					</ul>
				</div>
			</nav>
		</header>
		<!-- END HEADER MOBILE-->

		<!-- MENU SIDEBAR-->
		<aside class="menu-sidebar d-none d-lg-block">
			<div class="logo">
				<a href="#">
					<img src="images/icon/logo.png" alt="Cool Admin" />
				</a>
			</div>
			<div class="menu-sidebar__content js-scrollbar1">
				<nav class="navbar-sidebar">
					<ul class="list-unstyled navbar__list">
						<li class="has-sub">
							<a class="js-arrow" href="index.php">
								<i class=""></i>Dashboard</a>
						</li>
						<li>
							<a href="quest_ppr.php">
								<i class=""></i>Question Paper</a>
						</li>
						<li>
                            <a href="prev_ppr.php">
                                <i class=""></i>Previous papers</a>
                        </li>
                        <li>
                            <a href="calendar.php">
                                <i class=""></i>Planner</a>
                        </li>
                        <li>
                            <a href="search.php">
                                <i class=""></i>Google</a>
                        </li>

					</ul>
				</nav>
			</div>
		</aside>
		<!-- END MENU SIDEBAR-->

		<!-- PAGE CONTAINER-->
		<div class="page-container">
			<!-- HEADER DESKTOP-->
			<header class="header-desktop">
				<div class="section__content section__content--p30">
					<div class="container-fluid">
						<div class="header-wrap">
						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
							<div class="header-button">
								<div class="noti-wrap">
								</div>
								<div class="account-wrap">
									<div class="account-item clearfix js-item-menu">
										<div class="image">
										<?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
										</div>
										<div class="content">
											<a class="js-acc-btn" href="#"><?php echo $_SESSION['firstname']; ?></a>
										</div>
										<div class="account-dropdown js-dropdown">
											<div class="info clearfix">
												<div class="image">
													<a href="#">
													<?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
													</a>
												</div>
												<div class="content">
													<h5 class="name">
														<a href="#"><?php echo $_SESSION['firstname'] . " " . $_SESSION['lastname']; ?></a>
													</h5>
													<span class="email"><?php echo $_SESSION['user_email']; ?></span>
												</div>
											</div>
											<div class="account-dropdown__footer">
												<a href="../login/logout.php">
													<i class="zmdi zmdi-power"></i>Logout</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
			<!-- HEADER DESKTOP-->
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<div class="section__content section__content--p30">
					<h1 style="text-align: center">Set Question Paper</h1>
					<br>
					<br>
					<div class="container">
                   <div class="row">
     	<br>
     	<br>
     	<br>
			 
			    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               
					<div class="box-part text-center">
                        
						<div class="title">
							<h3>UT</h3>
						</div>
                        
						<div class="text">
							<span>Set paper for unit tests</span>
						</div>
                        
						<a href="set_ppr2.php">set paper</a>
                        
					 </div>
				</div>	 
				
				 <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
               
					<div class="box-part text-center">
                    
						<div class="title">
							<h3>Prelims</h3>
						</div>
                        
						<div class="text">
							<span>Set paper for prelims</span>
						</div>
                        
						<a href="neet.php">set paper</a>
                        
					 </div>
				</div>	 
		
		</div>
					    
					</div>
				</div>
			</div>
			<section>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Copyright © 2018 ELIT. All rights reserved.<br> Made with love by <a href="https://www.namanlazarus02.wixsite.com/elit">ELIT</a>.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
		</div>
		
		<!-- END PAGE CONTAINER-->

	</div>
	
	

	<!-- Jquery JS-->
	<script src="vendor/jquery-3.2.1.min.js"></script>
<?php include "script.php"; ?>
	<!-- Main JS-->
	<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
