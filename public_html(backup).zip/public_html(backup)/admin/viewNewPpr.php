<?php 
include "../includes/db.php";
if(isset($_POST['submit'])) {
    $query = "SELECT * FROM newppr ORDER BY id DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    /* if(!$result) {
        die("Failed! " . mysqli_error($conn));
    }
    else {
        echo "Success!!";
    } */
    
    $row = mysqli_fetch_array($result);
    
}

?>
<!DOCTYPE html>
<html>

<head>
<title>QBank</title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
<img src="images/pprLogo.png" style="position: relative; left: 730px" width="5%" alt="">
    <h1 style="text-align: center"><i>Fr. C. Rodrigues Institute of Technology, Vashi.</i></h1>
    <h4 style="text-align: center"><u>Question Paper</u></h4><br><br>
    <div class="container">
    <div class="row">
       <div class="col-sm-1">
           <p>  </p>
       </div>
        <div class="col-sm-3">
            <p>Subject: CNS</p>
        </div>
        <div class="col-sm-4">Total Marks: <?php echo $row['ttlMarks']; ?></div>
        
        <div class="col-sm-4">
            <p>Date: 23-10-2019</p>
        </div>
    </div>
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   <br>
    <table class="table">
        <tr>
            <td><b>Q1. <?php echo $row['que1_title']; ?></b></td>
        </tr>
        <tr>
            <td>Q1. a. <?php echo $row['q1_sq1']; ?><span style="text-align: right"><?php ?></span></td>
        </tr>
        <tr>
            <td>Q1. b. <?php echo $row['q1_sq2']; ?></td>
        </tr>
        <tr>
            <td>Q1. c. <?php echo $row['q1_sq3']; ?></td>
        </tr>
    </table>
    </div>
</body>

</html>


