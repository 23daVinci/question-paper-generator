<?php session_start();
if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>QBank</title>
    <?php include "includes/links.php"; ?>

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/new_logo.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class=""></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="chart.html">
                                <i class=""></i>Question paper</a>
                        </li>
                        <li>
                            <a href="prev_ppr.php">
                                <i class=""></i>Previous papers</a>
                        </li>
                        <li>
                            <a href="calendar.php">
                                <i class=""></i>Planner</a>
                        </li>
                        <li>
                            <a href="search.php">
                                <i class=""></i>Google</a>
                        </li>

                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/new_logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class=""></i>Dashboard</a>
                        </li>
                        <li class="active has-sub">
                            <a href="quest_ppr.php">
                                <i class=""></i>Question paper</a>
                        </li>
                        <li>
                            <a href="prev_ppr.php">
                                <i class=""></i>Previous papers</a>
                        </li>
                        <li>
                            <a href="calendar.php">
                                <i class=""></i>Planner</a>
                        </li>
                        <li>
                            <a href="search.php">
                                <i class=""></i>Google</a>
                        </li>
                        <li>
                            <a href="newPpr.php">
                                <button class="btn btn-success">Make a new paper</button>
                            </a>
                        </li>

                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <div class="header-button">
                                <div class="noti-wrap">

                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">
                                                <?php echo $_SESSION['firstname']; ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#">
                                                            <?php echo $_SESSION['firstname'] . " " . $_SESSION['lastname']; ?></a>
                                                    </h5>
                                                    <span class="email">
                                                        <?php echo $_SESSION['user_email']; ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="../login/logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <h1 style="text-align: center">Question Paper Module</h1>
                    <br>
                    <br>
                    <br>
                    <!-- cards -->
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card" style="width:400px">
                                <img class="card-img-top" src="images/2.png" alt="Card image" style="width:100%">
                                <div class="card-body">
                                    <h4 class="card-title">Set question paper</h4>
                                    <p class="card-text">Choose from the list or add one of your own question</p><br>
                                    <a href="../set_ppr/set_ppr.php" class="btn btn-primary">Set Paper</a>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="card" style="width:400px">
                                <div class="card-body">
                                    <h4 class="card-title">Add New Questions</h4>
                                    <p class="card-text">Add new questions to the repository.</p><br>
                                    <a href="../add_quest/select_co.php" class="btn btn-primary">Add Questions</a>
                                </div>
                                <img class="card-img-bottom" src="images/1.png" alt="Card image" style="width:100%">
                            </div>
                        </div>
                    </div>
                    <br>
                </div>
            </div>
            <section>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Copyright © 2018 ELIT. All rights reserved.<br> Made with love by <a href="https://www.namanlazarus02.wixsite.com/elit">ELIT</a>.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- END PAGE CONTAINER-->

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <?php include "script.php"; ?>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
