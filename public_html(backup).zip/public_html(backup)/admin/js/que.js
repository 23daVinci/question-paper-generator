var index = [];
// Array starts with 0 but the id start with 0 so push a dummy value
index.push(0);
// Push 1 at index 1 since one child element is already created
index.push(1)

function addkid() {
  
  var div = document.createElement('div');
  var id = getID();
  // Set this attritube id so that we can access this element using Id 
  div.setAttribute("id","Div_"+id);
  
  div.innerHTML = 'Sub question ' + id + ': <textarea class="form-control" type="text" name="sq1_' + id + '"></textarea>' + '<input class="form-control col-sm-2" placeholder="Marks" type="number" name="mrk1_' + id + '"/><br>' + ' <input class="btn btn-primary" type="button" id="add_kid()_' + id + '" onclick="addkid()" value="+" />' + '<input class="btn btn-danger" type="button" id="rem_kid()_' + id + '" onclick="remkid('+id+')" value="-" /><br><br>';
  // inside of passing this parameter in remkid we pass id number
  document.getElementById('kids').appendChild(div);
}
   
function remkid(id) {
// use the id arugment to get the div element using unique id set in addkid
  try{
var element = document.getElementById("Div_"+id)
element.parentNode.removeChild(element);
    index[id] = -1;
    //id number is = index of the array so we set to -1 to indicate its empty
    }
  catch(err){
    alert("id: Div_"+id)
    alert(err)
    
    }
}  
 function getID(){
   var emptyIndex = index.indexOf(-1);
   if (emptyIndex != -1){
     index[emptyIndex] = emptyIndex
     
     return emptyIndex
   } else {
   emptyIndex = index.length
   index.push(emptyIndex)
   return emptyIndex
     }
   }
  