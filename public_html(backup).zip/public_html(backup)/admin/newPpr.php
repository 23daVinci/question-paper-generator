<?php session_start();
if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>QBank</title>
    <?php include "includes/links.php"; ?>

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">


</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/new_logo.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class=""></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="chart.html">
                                <i class=""></i>Question paper</a>
                        </li>
                        <li>
                            <a href="prev_ppr.php">
                                <i class=""></i>Previous papers</a>
                        </li>
                        <li>
                            <a href="calendar.php">
                                <i class=""></i>Planner</a>
                        </li>
                        <li>
                            <a href="search.php">
                                <i class=""></i>Google</a>
                        </li>

                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/new_logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class=""></i>Dashboard</a>
                        </li>
                        <li class="active has-sub">
                            <a href="quest_ppr.php">
                                <i class=""></i>Question paper</a>
                        </li>
                        <li>
                            <a href="prev_ppr.php">
                                <i class=""></i>Previous papers</a>
                        </li>
                        <li>
                            <a href="calendar.php">
                                <i class=""></i>Planner</a>
                        </li>
                        <li>
                            <a href="search.php">
                                <i class=""></i>Google</a>
                        </li>

                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <div class="header-button">
                                <div class="noti-wrap">

                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">
                                                <?php echo $_SESSION['firstname']; ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#">
                                                            <?php echo $_SESSION['firstname'] . " " . $_SESSION['lastname']; ?></a>
                                                    </h5>
                                                    <span class="email">
                                                        <?php echo $_SESSION['user_email']; ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="../login/logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <h1 style="text-align: center">Create a new pattern for question paper.</h1><br>
                    <!-- form -->
                    <div class="container">
                        <!-- question no. 1 -->
                        <form action="includes/newPpr.php" method="post">
                            <div class="row">
                                <div class="col-sm-4">
                                    <label for="">Give a unique name to your paper: </label>
                                    <input type="text" class="form-control" name="pprName">
                                </div>
                                <div class="col-sm-4">
                                    <label for="">Enter the total no. of questions: </label>
                                    <input type="number" class="form-control" name="ttlQues">
                                </div>
                                <div class="col-sm-4">
                                    <label for="">Total marks: </label>
                                    <input type="number" class="form-control" name="ttlMarks">
                                </div>
                            </div>
<b>---------------------------------------------------------------------------------------------------------------------------------</b>

                            <br><br>
                            <label for="">Question no. 1: </label>
                            <textarea class="form-control" placeholder="Enter the title of the question." type="text" name="majQue1"></textarea>
                            <br />
                            <input type="number" class="form-control col-sm-3" placeholder="no. of sub questions" name="subQue1"><br>
                            <div id="kids">
                                <label for="">Sub question 1: </label>
                                <textarea class="form-control" type="text" name="sq1_1"></textarea>
                                <input class="form-control col-sm-2" placeholder="Marks" type="number" name="mrk_1"/>
                                <input class="btn btn-primary" type="button" id="add_kid()_1" onclick="addkid()" value="+" />
                            </div><br>
                            <br>
                            <input class="btn btn-success" type="submit" name="submit" value="submit" />
                        </form>
                    </div>
                </div>
            </div>

            <!-- footer -->
            <section>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Copyright © 2018 ELiT. All rights reserved.<br> Made with love by <a href="http://elit-web-services.000webhostapp.com/ELiT/">ELiT</a>.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!-- END PAGE CONTAINER-->

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <?php include "script.php"; ?>

    <!-- Main JS-->
    <script src="js/main.js"></script>
    <script src="js/que.js"></script>
</body>

</html>
<!-- end document-->
