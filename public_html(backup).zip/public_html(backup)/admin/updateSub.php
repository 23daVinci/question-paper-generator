<?php session_start();
if(!isset($_SESSION['userId']))
{
    // not logged in
    header('Location: ../login/alogin.php');
    exit();
}
include "../includes/db.php";
if(isset($_POST['update'])){
    $upBranch = $_POST['upBranch'];
    $fromSub = $_POST['fromSub'];
    $toSub = $_POST['toSub'];
    
    $query1 = "UPDATE $upBranch SET `sub` = '$toSub' WHERE `sub` = '$fromSub'";
    $result1 = mysqli_query($conn, $query1);
    if(!$result1){
        die("ERROR!". mysqli_error($conn));
    }
    else{
        echo "DONE!";
    }
}

if(isset($_POST['remove'])){
    $delBranch = $_POST['delBranch'];
    $delSub = $_POST['delSub'];
    
    $query2 = "DELETE FROM $delBranch WHERE `sub` = '$delSub'";
    $result2 = mysqli_query($conn, $query2);
    if(!$result2){
        die("ERROR!". mysqli_error($conn));
    }
    else{
        echo "DONE!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>QBank</title>
    <?php include "includes/links.php"; ?>

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/new_logo.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class=""></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="chart.html">
                                <i class=""></i>Question paper</a>
                        </li>
                        <li>
                            <a href="prev_ppr.php">
                                <i class=""></i>Previous papers</a>
                        </li>
                        <li>
                            <a href="calendar.php">
                                <i class=""></i>Planner</a>
                        </li>
                        <li>
                            <a href="search.php">
                                <i class=""></i>Google</a>
                        </li>

                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/new_logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="has-sub">
                            <a class="js-arrow" href="index.php">
                                <i class=""></i>Dashboard</a>
                        </li>
                        <li class="has-sub">
                            <a href="quest_ppr.php">
                                <i class=""></i>Question paper</a>
                        </li>
                        <li class="active has-sub">
                            <a href="updateSub.php">
                                <i class=""></i>Update Subjects</a>
                        </li>
                        <li>
                            <a href="prev_ppr.php">
                                <i class=""></i>Previous papers</a>
                        </li>
                        <li>
                            <a href="calendar.php">
                                <i class=""></i>Planner</a>
                        </li>
                        <li>
                            <a href="search.php">
                                <i class=""></i>Google</a>
                        </li>

                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                        <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo $_SESSION['firstname']; ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                    <?php echo "<img src='images/" . $_SESSION['uimage'] . "' />" ?>
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo $_SESSION['firstname'] . " " . $_SESSION['lastname']; ?></a>
                                                    </h5>
                                                    <span class="email"><?php echo $_SESSION['user_email']; ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href="../login/logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                  <h1 style="text-align: center">QBank Subject Updations Portal</h1>
                   <br>
                   <br>
                   <br>
                   <div class="row">
                       <div class="col-sm-1">
                           <p>  </p>
                       </div>
                       <div class="col-sm-4">
                           <h3>Removing a Subject.</h3>
                           <br>
                           <form action="" method="post">
                               <p>Branch:</p>
                               <input type="text" name="delBranch">
                               <br><br>
                               <p>Enter the name of the subject you want to remove:</p>
                               <input type="text" name="delSub"><br><br>
                               <input type="submit" class="btn btn-danger" value="Remove" name="remove">
                           </form>
                       </div>
                       <div class="col-sm-1">
                           <p>  </p>
                       </div>
                       <div class="col-sm-4">
                           <h3>Updating a Subject.</h3>
                           <br>
                           <form action="" method="post">
                               <p>Branch:</p>
                               <input type="text" name="upBranch">
                               <br><br>
                               <p>Enter the old name of the subject:</p>
                               <input type="text" name="fromSub"><br><br>
                               <p>Enter the new name of the subject:</p>
                               <input type="text" name="toSub"><br><br>
                               <input type="submit" class="btn btn-primary" value="Update" name="update">
                           </form>
                       </div>
                   </div>
                    
                </div>
            </div>
            
            
            
            <!-- footer -->
            <section>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Copyright © 2018 ELiT. All rights reserved.<br> Made with love by <a href="http://elit-web-services.000webhostapp.com/ELiT/">ELiT</a>.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        
        <!-- END PAGE CONTAINER-->

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <?php include "script.php"; ?>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->