<?php

if(isset($_POST['period']) && $_FILES['ppr']['size'] > 0) {
    
    $branch = $_POST['branch'];
    $sem = $_POST['sem'];
    $sub = $_POST['sub'];
    $fileName = $_FILES['ppr']['name'];
    $tmpName  = $_FILES['ppr']['tmp_name'];
    $fileSize = $_FILES['ppr']['size'];
    $fileType = $_FILES['ppr']['type'];

    $fp      = fopen($tmpName, 'r');
    $content = fread($fp, filesize($tmpName));
    $content = mysql_real_escape_string($content);
    fclose($fp);

    $fileName = str_replace(' ', '', $fileName);

    if(!get_magic_quotes_gpc())
    {
        $fileName = addslashes($fileName);
    }

    
    $query = "INSERT INTO prevpprs (`branch`, `sem`, `sub`, `name`, `type`, `size`, `content`) VALUES('$branch', '$sem', '$sub', '" . mysql_real_escape_string($fileName) . "', '$fileType', '$fileSize', '$content')";

    $result = mysql_query($conn, $query);
    if(!$result){
        die('<br>Error, file upload failed ' . mysql_error($conn));
    }
    else{
    echo "<br>File <i>$fileName</i> uploaded!<br>";
    }
    }

?>